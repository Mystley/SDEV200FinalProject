public abstract class Donations
{
	public abstract void usage(String item);
	public void thankDonator()
	{
		System.out.println("Thank you for donating today!");
	}
}
